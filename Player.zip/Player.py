# Author: Brandon Jacks
# Section: CIS 225 01
# Date: 11/18/22
# File: Player.py
#
# A simple program to define a player class.

class Player:
    def __init__(self):
        self.name = ''
        self.jersey_num = 0
        self.pos = ''
